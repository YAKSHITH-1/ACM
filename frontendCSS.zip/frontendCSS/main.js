/* ══════════════════════════════════════════════════
       BACKGROUND ENGINE
   Vanilla JS port of the React StarsBackground component.
   Three animated layers + spring-eased mouse parallax.
   Fully theme-aware (dark = white stars, light = teal/amber).
   ══════════════════════════════════════════════════ */
(function initStars() {
  const canvas = document.createElement("canvas");
  canvas.id = "stars-canvas";
  document.body.insertBefore(canvas, document.body.firstChild);
  const ctx = canvas.getContext("2d");

  // ── Config ──────────────────────────────────────
  const LAYERS = [
    { count: 1000, size: 1, speed: 0.15 },
    { count: 400, size: 1.5, speed: 0.30 },
    { count: 200, size: 2.5, speed: 0.55 },
  ];
  const PARALLAX_FACTOR = 0.04;
  const SPRING_STIFFNESS = 0.06;

  // ── State ────────────────────────────────────────
  let W = 0, H = 0;
  let mouseX = 0, mouseY = 0;
  let springX = 0, springY = 0;
  let velX = 0, velY = 0;
  let layers = [];
  let particles = [];
  let animFrame;

  // ── Theme helper ─────────────────────────────────
  function getStarColors() {
    const isLight = document.documentElement.classList.contains("light-theme") || document.body.classList.contains("light-theme");
    if (isLight) {
      // Slightly deeper, more visible pastel aurora palette
      return ["#34D399", "#60A5FA", "#FBBF24", "#6EE7B7", "#A78BFA", "#FCD34D"];
    }
    return ["rgba(255,255,255,0.9)", "rgba(255,255,255,0.7)", "rgba(255,255,255,0.5)"];
  }

  // ── Build star layers ─────────────────────────────
  function buildLayers() {
    const colors = getStarColors();
    const isLight = document.documentElement.classList.contains("light-theme") || document.body.classList.contains("light-theme");

    if (isLight) {
      particles = [];
      for (let i = 0; i < 6; i++) {
        particles.push({
          x: Math.random() * (W || window.innerWidth),
          y: Math.random() * (H || window.innerHeight),
          vx: (Math.random() - 0.5) * 1.5,
          vy: (Math.random() - 0.5) * 1.5,
          radius: Math.random() * 300 + 300,
          color: colors[i % colors.length]
        });
      }
      layers = [];
    } else {
      particles = [];
      layers = LAYERS.map((cfg) => {
        const stars = [];
        for (let i = 0; i < cfg.count; i++) {
          stars.push({
            x: Math.random() * 4000 - 2000,
            y: Math.random() * 4000 - 2000,
            color: colors[Math.floor(Math.random() * colors.length)]
          });
        }
        return { ...cfg, stars, offset: 0 };
      });
    }
  }

  // ── Resize ────────────────────────────────────────
  function resize() {
    const dpr = window.devicePixelRatio || 1;
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.width = W + "px";
    canvas.style.height = H + "px";
    ctx.scale(dpr, dpr);
  }

  // ── Draw frame ───────────────────────────────────
  function draw(ts) {
    ctx.clearRect(0, 0, W, H);

    // Spring physics toward mouse target
    const targetX = mouseX * PARALLAX_FACTOR;
    const targetY = mouseY * PARALLAX_FACTOR;
    velX += (targetX - springX) * SPRING_STIFFNESS;
    velY += (targetY - springY) * SPRING_STIFFNESS;
    velX *= 0.85;
    velY *= 0.85;
    springX += velX;
    springY += velY;

    const isLight = document.documentElement.classList.contains("light-theme") || document.body.classList.contains("light-theme");

    if (isLight) {
      // Voronoi WebGL canvas handles light-mode background — skip gradient mesh
      animFrame = requestAnimationFrame(draw);
      return;
    } else {
      if (canvas.style.filter !== 'none' && canvas.style.filter !== '') canvas.style.filter = 'none';
      layers.forEach((layer) => {
        // Scroll offset for this layer (continuous vertical drift)
        layer.offset = (layer.offset + layer.speed) % H;

        layer.stars.forEach((star) => {
          // Map star coords from [-2000,2000] range to screen
          const baseX = ((star.x + 2000) / 4000) * W;
          const baseY = ((star.y + 2000) / 4000) * H;

          // Apply vertical scroll + parallax
          const drawX = baseX + springX * layer.size;
          const drawY = ((baseY + layer.offset + springY * layer.size) % H + H) % H;

          ctx.beginPath();
          ctx.arc(drawX, drawY, layer.size / 2, 0, Math.PI * 2);
          ctx.fillStyle = star.color;
          ctx.fill();
        });
      });
    }

    animFrame = requestAnimationFrame(draw);
  }

  // ── Mouse tracking ───────────────────────────────
  document.addEventListener("mousemove", (e) => {
    mouseX = -(e.clientX - W / 2);
    mouseY = -(e.clientY - H / 2);
  });

  // ── Theme change: rebuild star colors ────────────
  // Watch for class changes on body (theme toggle)
  const observer = new MutationObserver(() => {
    buildLayers();
  });
  observer.observe(document.body, { attributes: true, attributeFilter: ["class"] });

  // ── Init ─────────────────────────────────────────
  resize();
  buildLayers();
  requestAnimationFrame(draw);
  window.addEventListener("resize", () => { resize(); });

  // Pause when tab is hidden to save resources
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      cancelAnimationFrame(animFrame);
    } else {
      requestAnimationFrame(draw);
    }
  });
})();

document.addEventListener("DOMContentLoaded", () => {
  // --- CONFIGURATION ---
  // API URL is configurable via window.APP_CONFIG or defaults to the active backend
  const DEFAULT_PROD_API = "https://api.acmjit.com/api";
  let configuredApi = (typeof window !== "undefined" && window.APP_CONFIG && window.APP_CONFIG.API_BASE_URL)
    ? window.APP_CONFIG.API_BASE_URL.replace(/\/$/, "")
    : DEFAULT_PROD_API;
  if (configuredApi && !configuredApi.endsWith("/api") && !configuredApi.includes("localhost") && !configuredApi.includes("127.0.0.1")) {
    configuredApi = `${configuredApi}/api`;
  }
  const isLocal = window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1" ||
    window.location.protocol === "file:";
  const API_BASE_URL = isLocal ? "http://localhost:5000/api" : configuredApi;
  const PROD_BACKEND_URL = configuredApi;
  // ---------------------

  // --- Dark/Light Theme Custom Design System Overrides ---


  // Force migration to light mode for existing users (run once)
  if (!localStorage.getItem("migrated_to_light_default")) {
    localStorage.setItem("theme", "light");
    localStorage.setItem("migrated_to_light_default", "true");
  }

  // Apply saved theme immediately
  const savedTheme = localStorage.getItem("theme") || "light";
  if (savedTheme === "light") {
    document.body.classList.add("light-theme");
    document.documentElement.classList.add("light-theme");
  } else {
    document.body.classList.remove("light-theme");
    document.documentElement.classList.remove("light-theme");
  }

  // --- USER SANITIZER & STORAGE CLEANUP ---
  const sanitizeUser = (user) => {
    if (!user || typeof user !== "object") return null;
    return {
      _id: user._id || user.id || "",
      name: user.name || user.fullName || "",
      email: user.email || "",
      role: user.role || "user",
      avatar: user.avatar || "",
      isVerified: Boolean(user.isVerified)
    };
  };

  // Clean any old insecure storage entries (e.g. containing refresh tokens or internal fields)
  try {
    const rawStoredUser = localStorage.getItem("user");
    if (rawStoredUser) {
      const parsedStoredUser = JSON.parse(rawStoredUser);
      const cleanedUser = sanitizeUser(parsedStoredUser);
      if (cleanedUser && (cleanedUser._id || cleanedUser.email)) {
        localStorage.setItem("user", JSON.stringify(cleanedUser));
      } else {
        localStorage.removeItem("user");
      }
    }
  } catch (e) {
    localStorage.removeItem("user");
  }

  // --- GUEST ROUTE GUARD ---
  // Redirect authenticated users away from guest-only auth pages (join-us, register)
  const currentPath = window.location.pathname;
  const currentPageName = currentPath.split("/").pop() || "index.html";
  const isGuestAuthPage = currentPageName === "join-us.html" ||
                          currentPageName === "register.html" ||
                          currentPath.endsWith("/join-us") ||
                          currentPath.endsWith("/register");

  if (isGuestAuthPage && localStorage.getItem("token")) {
    window.location.replace("index.html");
    return;
  }

  const DEFAULT_EVENTS = {
    upcoming: [],
    past: []
  };

  const fetchEvents = async () => {
    try {
      const res = await fetch(`${API_BASE_URL}/events`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.upcoming) && Array.isArray(data.past)) {
          return { upcoming: data.upcoming || [], past: data.past || [] };
        }
      }
    } catch (err) {
      console.warn("Local backend not reachable, checking fallback / production backend...", err);
      try {
        if (API_BASE_URL !== PROD_BACKEND_URL) {
          const resProd = await fetch(`${PROD_BACKEND_URL}/events`);
          if (resProd.ok) {
            const dataProd = await resProd.json();
            if (dataProd.success && Array.isArray(dataProd.upcoming) && Array.isArray(dataProd.past)) {
              return { upcoming: dataProd.upcoming || [], past: dataProd.past || [] };
            }
          }
        }
      } catch (errProd) {
        console.warn("Prod fallback fetch failed, using default events:", errProd);
      }
    }
    return DEFAULT_EVENTS;
  };

  const escapeHtml = (value) =>
    String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");

  /* Status badge: returns inline style string */
  const statusStyle = (status) => {
    const s = (status || "").toLowerCase();
    if (s.includes("closed")) return "background:rgba(244,63,94,0.1);color:#fda4af;";
    if (s.includes("open")) return "background:rgba(52,211,153,0.1);color:#6ee7b7;";
    if (s.includes("soon")) return "background:rgba(251,191,36,0.1);color:#fcd34d;";
    if (s.includes("fast")) return "background:rgba(34,211,238,0.1);color:#67e8f9;";
    return "background:rgba(244,63,94,0.1);color:#fda4af;";
  };

  const formatDisplayDate = (dStr) => {
    if (!dStr) return "TBA";
    try {
      const d = new Date(dStr);
      if (!isNaN(d.getTime())) {
        return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
      }
    } catch { }
    return dStr;
  };

  /* ── Unique Vibrant Event Color Themes (Distinct from Know Us) ── */
  const EVENT_THEMES = [
    {
      themeClass: "theme-indigo",
      category: "Workshop & Lab",
      stickerSvg: `<svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>` // Lightning 
    },
    {
      themeClass: "theme-coral",
      category: "Hackathon & Challenge",
      stickerSvg: `<svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.45 1-1 1H7v2h10v-2h-2c-.55 0-1-.45-1-1v-2.34"/><path d="M6 4h12v7a6 6 0 0 1-12 0V4Z"/></svg>` // Trophy 🏆
    },
    {
      themeClass: "theme-emerald",
      category: "Tech Talk & Keynote",
      stickerSvg: `<svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/></svg>` // Code 💻
    },
    {
      themeClass: "theme-sky",
      category: "Code Sprint & Demo",
      stickerSvg: `<svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>` // Rocket 🚀
    },
    {
      themeClass: "theme-fuchsia",
      category: "Bootcamp & Track",
      stickerSvg: `<svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>` // Target 🎯
    },
    {
      themeClass: "theme-lime",
      category: "Innovation & Pitch",
      stickerSvg: `<svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>` // Star ⭐
    },
    {
      themeClass: "theme-amber",
      category: "Chapter Summit",
      stickerSvg: `<svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>` // Badge 
    },
    {
      themeClass: "theme-teal",
      category: "Open Source & Lab",
      stickerSvg: `<svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>` // Grid 
    }
  ];

  const renderPublicEvents = async () => {
    const upcomingList = document.getElementById("upcoming-events-list");
    const pastList = document.getElementById("past-events-list");
    if (!upcomingList || !pastList) return;

    const events = await fetchEvents();

    /* ── Upcoming ── */
    if (events.upcoming.length) {
      upcomingList.innerHTML = events.upcoming.map((event, i) => {
        const theme = EVENT_THEMES[i % EVENT_THEMES.length];
        const st = (event.status || "").toLowerCase();
        const isOpen = st.includes("open") && !st.includes("closed");
        const displayDate = formatDisplayDate(event.date);
        const buttonDataAttrs = isOpen
          ? `data-reg-event-id="${escapeHtml(event._id || "")}" data-reg-event-title="${escapeHtml(event.title || "")}" data-reg-event-team-size="${escapeHtml(String(event.teamSize || 1))}"`
          : "";

        return `
          <article class="upcoming-neo-card ${theme.themeClass}">
            <div class="upcoming-neo-header">
              <div class="upcoming-neo-date">
                <svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                <span>${escapeHtml(displayDate)}</span>
              </div>
              <span class="upcoming-neo-status">${escapeHtml(event.status || "Upcoming")}</span>
            </div>
            <div>
              <div style="font-family:'Caveat',cursive;font-size:1.25rem;font-weight:700;color:#0B0F0D;margin-bottom:0.15rem;">${theme.category}</div>
              <h3 class="upcoming-neo-title">${escapeHtml(event.title)}</h3>
              <p class="upcoming-neo-desc" style="margin-top:0.4rem;">${escapeHtml(event.description)}</p>
            </div>
            <div class="upcoming-neo-footer">
              <span style="font-size:0.78rem;font-weight:800;color:#0B0F0D;background:rgba(255,255,255,0.7);padding:0.25rem 0.6rem;border-radius:8px;border:1.5px solid #0B0F0D;box-shadow:1.5px 1.5px 0px #0B0F0D;">
                👥 Team: ${escapeHtml(String(event.teamSize || 1))} Max
              </span>
              ${isOpen ? `<button type="button" class="upcoming-neo-btn btn-register-event" ${buttonDataAttrs}>Reserve Spot →</button>` : ''}
            </div>
          </article>`;
      }).join("");
    } else {
      upcomingList.innerHTML =
        '<p style="border-radius:20px;border:2.5px solid #0B0F0D;box-shadow:4px 4px 0px #0B0F0D;background:#ffffff;padding:1.5rem;color:#0B0F0D;font-weight:700;">No upcoming dynamic events currently scheduled.</p>';
    }

    /* ── Past ── */
    if (events.past.length) {
      pastList.innerHTML = events.past.map((event, i) => {
        const emojis = ["", "", "", "", "", "⭐", ""];
        const emoji = emojis[i % emojis.length];
        return `
          <div class="past-neo-card">
            <div class="past-neo-dot" style="background:#ffffff;">${emoji}</div>
            <div class="past-neo-info">
              <h3>${escapeHtml(event.title)}</h3>
              <p>${escapeHtml(event.description)}</p>
            </div>
          </div>`;
      }).join("");
    } else {
      pastList.innerHTML = '<p style="font-size:0.9rem;color:#64748b;font-weight:600;">No past events recorded yet.</p>';
    }
  };

  const renderAdminEvents = async () => {
    const adminList = document.getElementById("admin-events-list");
    if (!adminList) return;

    const events = await fetchEvents();
    const combined = [
      ...events.upcoming.map((e) => ({ ...e, type: "upcoming" })),
      ...events.past.map((e) => ({ ...e, type: "past" }))
    ];

    const formatDate = (d) => {
      if (!d) return "";
      try {
        return new Date(d).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
      } catch { return ""; }
    };

    if (combined.length) {
      adminList.innerHTML = combined.map((event) => {
        let regInfo = "";
        if (event.registrationOpenDate || event.registrationCloseDate) {
          const openStr = formatDate(event.registrationOpenDate);
          const closeStr = formatDate(event.registrationCloseDate);
          regInfo = `<p style="margin-top:0.5rem;font-size:0.8rem;color:#6ee7b7;">
            📅 Registration: ${openStr || "—"} → ${closeStr || "—"}
            <span style="margin-left:0.5rem;padding:0.15rem 0.5rem;border-radius:9999px;font-size:0.7rem;font-weight:900;${statusStyle(event.status)}">${escapeHtml(event.status)}</span>
          </p>`;
        } else if (event.status) {
          regInfo = `<p style="margin-top:0.5rem;font-size:0.8rem;color:#94a3b8;">${escapeHtml(event.status)}</p>`;
        }
        const eventId = event._id || event.id || "";
        return `
        <article style="border-radius:1rem;border:1px solid rgba(255,255,255,0.1);background:rgba(2,6,23,0.6);padding:1.25rem;">
          <div style="display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:space-between;gap:1rem;">
            <div>
              <p style="font-size:0.75rem;font-weight:900;text-transform:uppercase;letter-spacing:0.2em;color:#67e8f9;">${escapeHtml(event.type)}</p>
              <h3 style="margin-top:0.5rem;font-size:1.25rem;font-weight:900;color:#fff;">${escapeHtml(event.title)}</h3>
              <p style="margin-top:0.25rem;font-size:0.875rem;color:#94a3b8;">${escapeHtml(event.date || "")}</p>
              ${regInfo}
              <p style="margin-top:0.75rem;font-size:0.875rem;line-height:1.75;color:#cbd5e1;">${escapeHtml(event.description)}</p>
            </div>
            <button type="button"
              data-delete-event="${escapeHtml(eventId)}"
              data-delete-type="${escapeHtml(event.type || '')}"
              style="flex-shrink:0;border-radius:0.5rem;border:1px solid rgba(253,164,175,0.3);background:rgba(244,63,94,0.1);color:#fecdd3;font-weight:900;padding:0.5rem 0.75rem;font-size:0.875rem;cursor:pointer;font-family:inherit;"
              onmouseenter="this.style.background='rgba(244,63,94,0.2)'"
              onmouseleave="this.style.background='rgba(244,63,94,0.1)'"
            >Delete</button>
          </div>
        </article>`;
      }).join("");
    } else {
      adminList.innerHTML =
        '<p style="border-radius:1rem;border:1px solid rgba(255,255,255,0.1);background:rgba(2,6,23,0.6);padding:1.25rem;color:#cbd5e1;">No events saved yet.</p>';
    }
  };

  const setupAdminPanel = () => {
    const form = document.getElementById("event-admin-form");
    if (!form) return;

    const typeInput = document.getElementById("event-type");
    const regOpenWrap = document.getElementById("event-reg-open-wrap");
    const regCloseWrap = document.getElementById("event-reg-close-wrap");
    const teamSizeWrap = document.getElementById("event-team-size-wrap");
    const resetBtn = document.getElementById("reset-events");

    const toggleUpcomingFields = () => {
      const isPast = typeInput.value === "past";
      if (regOpenWrap) regOpenWrap.style.display = isPast ? "none" : "";
      if (regCloseWrap) regCloseWrap.style.display = isPast ? "none" : "";
      if (teamSizeWrap) teamSizeWrap.style.display = isPast ? "none" : "";
    };
    typeInput.addEventListener("change", toggleUpcomingFields);
    toggleUpcomingFields();

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const submitBtn = form.querySelector('button[type="submit"]');
      const origText = submitBtn ? submitBtn.textContent : "";
      if (submitBtn) submitBtn.textContent = "Saving...";

      const type = typeInput.value;
      const rawDate = document.getElementById("event-date").value;
      const newEvent = {
        title: document.getElementById("event-title").value.trim(),
        date: rawDate,
        description: document.getElementById("event-description").value.trim(),
        type: type
      };
      // Format the date for display (e.g., "June 15, 2026")
      let displayDate = rawDate;
      if (rawDate) {
        try {
          const d = new Date(rawDate + "T00:00:00");
          displayDate = d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
        } catch { /* keep raw value */ }
      }

      if (type === "upcoming") {
        const tsInput = document.getElementById("event-team-size");
        if (tsInput) {
          newEvent.teamSize = parseInt(tsInput.value) || 1;
        }
        const regOpen = document.getElementById("event-reg-open").value;
        const regClose = document.getElementById("event-reg-close").value;
        if (regOpen) newEvent.registrationOpenDate = new Date(regOpen + "T00:00:00").toISOString();
        if (regClose) {
          // Set close date to end of that day (23:59:59)
          newEvent.registrationCloseDate = new Date(regClose + "T23:59:59").toISOString();
        }
      }

      const token = localStorage.getItem("token");
      try {
        const res = await fetch(`${API_BASE_URL}/events`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
          },
          body: JSON.stringify(newEvent)
        });
        if (res.ok) {
          form.reset();
          toggleUpcomingFields();
          await renderAdminEvents();
        } else {
          const errData = await res.json().catch(() => ({}));
          alert("Failed to save event: " + (errData.message || "Unknown error"));
        }
      } catch (err) {
        console.error(err);
        alert("Server error while saving event");
      }
      if (submitBtn) submitBtn.textContent = origText;
    });

    document.addEventListener("click", async (e) => {
      const btn = e.target.closest("[data-delete-event]");
      if (!btn) return;

      const eventId = btn.dataset.deleteEvent;
      if (!eventId || eventId === "undefined" || eventId === "null") {
        alert("This event does not have a database ID. Please refresh the page to sync with database.");
        return;
      }

      if (!confirm("Are you sure you want to delete this event?")) return;

      const token = localStorage.getItem("token");
      try {
        const res = await fetch(`${API_BASE_URL}/events/${eventId}`, {
          method: "DELETE",
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.success) {
          await renderAdminEvents();
        } else {
          alert("Failed to delete event: " + (data.message || "Unknown error"));
        }
      } catch (err) {
        console.error(err);
        alert("Network or server error while deleting event.");
      }
    });

    resetBtn.addEventListener("click", () => {
      alert("Reset is disabled. Events are managed in the database now.");
    });

    renderAdminEvents();
  };

  const defaultAnnouncements = [
    {
      id: "ann-1",
      category: "cyan",
      badge: "Hackathon Alerts",
      time: "Today, 10:30 AM",
      title: "Internal hack sprint registration opens soon",
      body: "Teams can start preparing project ideas for a focused build weekend around web, AI, and campus-life problem statements."
    },
    {
      id: "ann-2",
      category: "violet",
      badge: "Core Update",
      time: "May 18, 2026",
      title: "Domain orientation schedule released",
      body: "New members can meet domain leads, understand chapter tracks, and choose where they want to contribute first."
    },
    {
      id: "ann-3",
      category: "emerald",
      badge: "Workshop",
      time: "May 15, 2026",
      title: "Git and GitHub hands-on lab completed",
      body: "Thanks to everyone who joined the collaborative workflow session. Resource links will be added to the hub shortly."
    }
  ];

  const announcementStoreKey = "acm-jit-announcements";

  const readAnnouncements = () => {
    const saved = localStorage.getItem(announcementStoreKey);
    if (!saved) return structuredClone(defaultAnnouncements);
    try {
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return structuredClone(defaultAnnouncements);
    }
  };

  const saveAnnouncements = (announcements) => {
    localStorage.setItem(announcementStoreKey, JSON.stringify(announcements));
  };

  let activeAnnFilter = "all";

  const renderPublicAnnouncements = (filter = activeAnnFilter) => {
    activeAnnFilter = filter;
    const list = document.getElementById("announcements-list");
    if (!list) return;

    let announcements = readAnnouncements();

    if (filter !== "all") {
      announcements = announcements.filter(ann => {
        const cat = (ann.category || "").toLowerCase();
        if (filter === "cyan") return cat === "cyan" || cat === "general" || (ann.badge && ann.badge.toLowerCase().includes("hack"));
        if (filter === "violet") return cat === "violet" || cat === "event" || (ann.badge && ann.badge.toLowerCase().includes("core"));
        if (filter === "emerald") return cat === "emerald" || (ann.badge && ann.badge.toLowerCase().includes("workshop"));
        if (filter === "rose") return cat === "rose" || cat === "alert" || (ann.badge && ann.badge.toLowerCase().includes("alert"));
        return cat === filter;
      });
    }

    if (announcements.length) {
      list.innerHTML = announcements.map((ann, index) => {
        const cat = escapeHtml(ann.category || "cyan");
        const tapeLabels = {
          cyan: "📌 SPRINT",
          violet: " CORE",
          emerald: "🛠 LAB",
          rose: " URGENT",
          amber: " NOTICE",
          general: " BULLETIN",
          event: " EVENT",
          alert: " ALERT"
        };
        const tapeText = tapeLabels[cat] || "📌 DISPATCH";

        return `
      <article class="space-card ${cat}" data-id="${escapeHtml(ann.id)}">
        <span class="space-card-tape">${tapeText}</span>
        
        <div class="item-meta">
          <div class="item-meta-left">
            <span class="item-badge">${escapeHtml(ann.badge || "Bulletin")}</span>
            <time class="item-time">⏱ ${escapeHtml(ann.time || "Recent")}</time>
          </div>
          <span class="item-index-num">#0${index + 1}</span>
        </div>

        <h3 class="item-title">${escapeHtml(ann.title)}</h3>
        <p class="item-body">${escapeHtml(ann.body)}</p>

        <div class="space-card-footer">
          <span class="space-card-stamp">
            <span>✦</span> Official Chapter Dispatch
          </span>
          <button type="button" class="space-share-btn" onclick="navigator.clipboard?.writeText('${escapeHtml(ann.title)}: ${escapeHtml(ann.body)}'); const b=this; b.innerHTML='✓ Copied!'; setTimeout(()=>{ b.innerHTML='<svg width=\\'12\\' height=\\'12\\' viewBox=\\'0 0 24 24\\' fill=\\'none\\' stroke=\\'currentColor\\' stroke-width=\\'2.5\\' stroke-linecap=\\'round\\' stroke-linejoin=\\'round\\'><rect x=\\'9\\' y=\\'9\\' width=\\'13\\' height=\\'13\\' rx=\\'2\\' ry=\\'2\\'></rect><path d=\\'M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\\'></path></svg> Share'; }, 2000);">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
            Share
          </button>
        </div>
      </article>`;
      }).join("");
    } else {
      list.innerHTML = `
        <div class="profile-empty-state" style="margin-top:0.5rem;">
          <p>No announcements found in this category.</p>
          <button class="profile-browse-btn" onclick="document.querySelector('.ann-tab-btn[data-cat=all]')?.click();">
            View All Dispatches
          </button>
        </div>`;
    }
  };

  // Wire up category filter tabs and sidebar legend clicks
  const setupAnnFilterTabs = () => {
    const tabs = document.querySelectorAll(".ann-tab-btn");
    tabs.forEach(tab => {
      tab.addEventListener("click", () => {
        tabs.forEach(t => t.classList.remove("is-active"));
        tab.classList.add("is-active");
        renderPublicAnnouncements(tab.dataset.cat);
      });
    });

    const legendItems = document.querySelectorAll(".ann-legend-item");
    legendItems.forEach(item => {
      item.addEventListener("click", () => {
        const filter = item.dataset.filter;
        const matchingTab = document.querySelector(`.ann-tab-btn[data-cat="${filter}"]`);
        if (matchingTab) {
          matchingTab.click();
        } else {
          renderPublicAnnouncements(filter);
        }
      });
    });
  };

  const renderAdminAnnouncements = () => {
    const adminList = document.getElementById("admin-announcements-list");
    if (!adminList) return;

    const announcements = readAnnouncements();

    if (announcements.length) {
      adminList.innerHTML = announcements.map((ann) => {
        let badgeColor = "#67e8f9"; // cyan default
        if (ann.category === "violet") badgeColor = "#c4b5fd";
        if (ann.category === "emerald") badgeColor = "#6ee7b7";
        return `
        <article style="border-radius:1rem;border:1px solid rgba(255,255,255,0.1);background:rgba(2,6,23,0.6);padding:1.25rem;">
          <div style="display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:space-between;gap:1rem;">
            <div>
              <p style="font-family:var(--font-heading,'Inter',sans-serif);font-size:0.75rem;font-weight:900;text-transform:uppercase;letter-spacing:0.2em;color:${badgeColor};">${escapeHtml(ann.badge)}</p>
              <h3 style="margin-top:0.5rem;font-size:1.25rem;font-weight:900;color:#fff;">${escapeHtml(ann.title)}</h3>
              <p style="margin-top:0.25rem;font-size:0.875rem;color:#94a3b8;">${escapeHtml(ann.time)}</p>
              <p style="margin-top:0.75rem;font-size:0.875rem;line-height:1.75;color:#cbd5e1;">${escapeHtml(ann.body)}</p>
            </div>
            <button type="button"
              data-delete-ann="${escapeHtml(ann.id)}"
              style="flex-shrink:0;border-radius:0.5rem;border:1px solid rgba(253,164,175,0.3);background:rgba(244,63,94,0.1);color:#fecdd3;font-weight:900;padding:0.5rem 0.75rem;font-size:0.875rem;cursor:pointer;font-family:inherit;"
              onmouseenter="this.style.background='rgba(244,63,94,0.2)'"
              onmouseleave="this.style.background='rgba(244,63,94,0.1)'">Delete</button>
          </div>
        </article>`;
      }).join("");
    } else {
      adminList.innerHTML =
        '<p style="border-radius:1rem;border:1px solid rgba(255,255,255,0.1);background:rgba(2,6,23,0.6);padding:1.25rem;color:#cbd5e1;">No announcements saved yet.</p>';
    }
  };

  const setupAdminAnnouncements = () => {
    const form = document.getElementById("announcement-admin-form");
    if (!form) return;

    const resetBtn = document.getElementById("reset-announcements");

    form.addEventListener("submit", (e) => {
      e.preventDefault();

      const categorySelect = document.getElementById("announcement-category");
      const category = categorySelect.value;
      const badge = categorySelect.options[categorySelect.selectedIndex].text.split(" (")[0];

      const newAnn = {
        id: `ann-${Date.now()}`,
        category: category,
        badge: badge,
        time: document.getElementById("announcement-time").value.trim(),
        title: document.getElementById("announcement-title").value.trim(),
        body: document.getElementById("announcement-body").value.trim()
      };

      const announcements = readAnnouncements();
      announcements.unshift(newAnn);
      saveAnnouncements(announcements);
      form.reset();
      renderAdminAnnouncements();
    });

    document.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-delete-ann]");
      if (!btn) return;
      let announcements = readAnnouncements();
      announcements = announcements.filter((item) => item.id !== btn.dataset.deleteAnn);
      saveAnnouncements(announcements);
      renderAdminAnnouncements();
    });

    resetBtn.addEventListener("click", () => {
      localStorage.removeItem(announcementStoreKey);
      renderAdminAnnouncements();
    });

    renderAdminAnnouncements();
  };

  const setButtonBusy = (button, label) => {
    if (!button) return;
    button.dataset.originalText = button.textContent;
    button.textContent = label;
    button.disabled = true;
    button.style.opacity = "0.82";
  };

  const restoreButton = (button) => {
    if (!button) return;
    button.textContent = button.dataset.originalText || button.textContent;
    button.disabled = false;
    button.style.opacity = "";
  };
  const showPopup = (title, message, options = {}) => {
    let popup = document.getElementById("popup");
    if (!popup) {
      popup = document.createElement("div");
      popup.id = "popup";
      document.body.appendChild(popup);
    }

    const isSuccess = title.toLowerCase().includes("success");
    const isError = title.toLowerCase().includes("fail") || title.toLowerCase().includes("error") || title.toLowerCase().includes("invalid");
    const tagClass = isSuccess ? "success" : isError ? "error" : "info";
    const tagLabel = isSuccess ? " SUCCESS" : isError ? " NOTICE" : " BULLETIN";

    popup.innerHTML = `
      <div id="popup-content">
        <div class="popup-tag-pill ${tagClass}">${tagLabel}</div>
        <h2 id="popup-title">${escapeHtml(title)}</h2>
        <p id="popup-message">${escapeHtml(message)}</p>
        <button id="popup-btn" type="button">Close</button>
      </div>
    `;

    popup.style.display = "flex";

    const closePopup = () => {
      popup.style.display = "none";
      if (options.onClose) options.onClose();
    };

    const popupBtn = document.getElementById("popup-btn");
    if (popupBtn) popupBtn.onclick = closePopup;

    popup.onclick = (e) => {
      if (e.target === popup) closePopup();
    };

    // Auto-close after 3 seconds for success messages
    if (isSuccess) {
      setTimeout(closePopup, 3000);
    }
  };

  const setupAuthForms = () => {
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");
    const verifyForm = document.getElementById("verify-form");
    const forgotPasswordForm = document.getElementById("forgot-password-form");

    if (loginForm) {
      loginForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const submitButton = loginForm.querySelector("button[type='submit']");
        const formData = new FormData(loginForm);

        setButtonBusy(submitButton, "Signing In...");

        try {
          const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: "POST",
            credentials: "include",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              email: formData.get("identifier"),
              password: formData.get("password"),
            }),
          });

          const data = await response.json();

          restoreButton(submitButton);

          if (!response.ok) {
            showPopup(
              "Login Failed",
              data.message || data.error || "Invalid credentials"
            );
            return;
          }

          // Clear previous session data before saving new login
          localStorage.removeItem("token");
          localStorage.removeItem("user");

          // Save new token and safe sanitized user
          localStorage.setItem("token", data.accessToken);
          if (data.user) {
            const safeUser = sanitizeUser(data.user);
            localStorage.setItem("user", JSON.stringify(safeUser));
            if (safeUser && safeUser.avatar) {
              localStorage.setItem(`user_avatar_${safeUser.email}`, safeUser.avatar);
            }
          }

          showPopup(
            "Success",
            "Login successful! Redirecting...",
            { onClose: () => { window.location.href = "index.html"; } }
          );

          setTimeout(() => {
            window.location.href = "index.html";
          }, 600);

          loginForm.reset();

        } catch (error) {
          console.error(error);
          restoreButton(submitButton);
          showPopup(
            "Server Error",
            "Unable to connect to server"
          );
        }
      });
    }

    if (registerForm) {
      registerForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const submitButton = registerForm.querySelector("button[type='submit']");
        const formData = new FormData(registerForm);

        setButtonBusy(submitButton, "Creating Account...");

        // Timeout after 30s so the button never stays stuck
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000);

        try {
          const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: "POST",
            credentials: "include",
            signal: controller.signal,
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              name: formData.get("fullName"),
              email: formData.get("email"),
              password: formData.get("password"),
            }),
          });

          clearTimeout(timeoutId);

          const data = await response.json();

          restoreButton(submitButton);

          if (!response.ok) {
            showPopup(
              "Registration Failed",
              data.message || "Unable to register"
            );
            return;
          }

          if (data.signupToken) {
            try { sessionStorage.setItem("signupToken", data.signupToken); } catch { }
          }

          const registeredEmail = formData.get("email");
          showPopup(
            "Success",
            "Registration successful! Check your inbox for the verification code.",
            { onClose: () => window.location.href = `verify.html?email=${encodeURIComponent(registeredEmail)}` }
          );

          registerForm.reset();

        } catch (error) {
          clearTimeout(timeoutId);
          console.error(error);
          restoreButton(submitButton);
          const msg = error.name === "AbortError"
            ? "Request timed out. Please try again."
            : "Unable to connect to server";
          showPopup(
            "Server Error",
            msg
          );
        }
      });
    }
    if (verifyForm) {
      // Auto-fill email from URL query param (passed from registration)
      const urlParams = new URLSearchParams(window.location.search);
      const prefillEmail = urlParams.get("email");
      const emailInput = verifyForm.querySelector("input[name='email']");
      if (prefillEmail && emailInput) {
        emailInput.value = prefillEmail;
        emailInput.readOnly = true;
        emailInput.style.opacity = "0.6";
        emailInput.style.cursor = "not-allowed";
      }
      verifyForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const submitButton = verifyForm.querySelector("button[type='submit']");
        const formData = new FormData(verifyForm);

        setButtonBusy(submitButton, "Confirming...");

        try {
          const signupToken = sessionStorage.getItem("signupToken") || undefined;
          const response = await fetch(`${API_BASE_URL}/auth/verify-email`, {
            method: "POST",
            credentials: "include",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              email: formData.get("email"),
              code: formData.get("verificationCode"),
              signupToken: signupToken
            }),
          });

          const data = await response.json();

          restoreButton(submitButton);

          if (!response.ok) {
            showPopup(
              "Verification Failed",
              data.message || "Invalid code or email"
            );
            return;
          }
          // Clear temporary signup token
          try { sessionStorage.removeItem("signupToken"); } catch { }
          // Auto-login: save token and safe sanitized user data
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          localStorage.setItem("token", data.accessToken);
          if (data.user) {
            const safeUser = sanitizeUser(data.user);
            localStorage.setItem("user", JSON.stringify(safeUser));
            if (safeUser && safeUser.avatar) {
              localStorage.setItem(`user_avatar_${safeUser.email}`, safeUser.avatar);
            }
          }

          showPopup(
            "Success",
            "Email verified! You're now signed in.",
            { onClose: () => window.location.href = "index.html" }
          );

          verifyForm.reset();

        } catch (error) {
          console.error(error);
          restoreButton(submitButton);
          showPopup(
            "Server Error",
            "Unable to connect to server"
          );
        }
      });
    }

    if (forgotPasswordForm) {
      const identifierInput = forgotPasswordForm.querySelector("[name='identifier']");
      const resetTokenInput = forgotPasswordForm.querySelector("[name='resetToken']");
      const newPasswordInput = forgotPasswordForm.querySelector("[name='newPassword']");
      const confirmPasswordInput = forgotPasswordForm.querySelector("[name='confirmPassword']");
      const requestField = forgotPasswordForm.querySelector("[data-reset-request-field]");
      const tokenNote = forgotPasswordForm.querySelector("[data-reset-token-note]");
      const passwordFields = forgotPasswordForm.querySelectorAll("[data-password-field]");

      let submittedEmail = "";
      let resetTokenSent = false;
      let tokenVerified = false;

      forgotPasswordForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const submitButton = forgotPasswordForm.querySelector("button[type='submit']");
        const formData = new FormData(forgotPasswordForm);

        if (!resetTokenSent) {
          submittedEmail = (formData.get("identifier") || "").trim().toLowerCase();
          if (!submittedEmail) {
            showPopup("Validation Error", "Please enter your registered email address.");
            return;
          }

          setButtonBusy(submitButton, "Sending Token...");

          try {
            const response = await fetch(
              `${API_BASE_URL}/auth/forgot-password`,
              {
                method: "POST",
                credentials: "include",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  email: submittedEmail,
                }),
              }
            );

            const data = await response.json();

            restoreButton(submitButton);

            if (!response.ok) {
              showPopup(
                "Error",
                data.message || "Failed to send reset token"
              );
              return;
            }

            resetTokenSent = true;

            if (requestField) requestField.style.display = "none";

            if (identifierInput) identifierInput.disabled = true;

            if (resetTokenInput) resetTokenInput.disabled = false;

            if (tokenNote) {
              tokenNote.style.display = "";
              tokenNote.textContent =
                "A secure reset token has been sent to your email (expires in 15 mins).";
            }

            submitButton.textContent = "Verify Token";

            resetTokenInput?.focus();

          } catch (error) {
            console.error(error);
            restoreButton(submitButton);
            showPopup(
              "Server Error",
              "Unable to connect to server"
            );
          }

          return;
        }

        const token = (formData.get("resetToken") || "").trim();
        if (!token) {
          showPopup("Validation Error", "Please enter the reset token sent to your email.");
          return;
        }

        if (!tokenVerified) {
          setButtonBusy(submitButton, "Verifying...");

          try {
            const response = await fetch(`${API_BASE_URL}/auth/verify-reset-token/${encodeURIComponent(token)}`, {
              method: "POST",
              credentials: "include",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                email: submittedEmail,
                token: token
              }),
            });

            const data = await response.json();
            restoreButton(submitButton);

            if (!response.ok) {
              showPopup("Error", data.message || "Invalid or expired token");
              return;
            }

            tokenVerified = true;
            if (resetTokenInput) {
              resetTokenInput.readOnly = true;
              resetTokenInput.style.opacity = "0.7";
            }

            passwordFields.forEach(field => field.style.display = "");
            if (newPasswordInput) newPasswordInput.disabled = false;
            if (confirmPasswordInput) confirmPasswordInput.disabled = false;

            submitButton.textContent = "Reset Password";
            newPasswordInput?.focus();
          } catch (error) {
            console.error(error);
            restoreButton(submitButton);
            showPopup("Server Error", "Unable to connect to server");
          }
          return;
        }

        const newPassword = formData.get("newPassword");
        const confirmPassword = formData.get("confirmPassword");

        if (newPassword !== confirmPassword) {
          showPopup("Error", "Passwords do not match");
          return;
        }

        setButtonBusy(submitButton, "Resetting...");

        try {
          const response = await fetch(
            `${API_BASE_URL}/auth/reset-password/${encodeURIComponent(token)}`,
            {
              method: "POST",
              credentials: "include",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                email: submittedEmail,
                token: token,
                password: newPassword,
              }),
            }
          );

          const text = await response.text();
          let data;

          try {
            data = JSON.parse(text);
          } catch {
            data = { message: "Unexpected server response" };
          }

          restoreButton(submitButton);

          if (!response.ok) {
            showPopup(
              "Error",
              data.message || "Failed to reset password"
            );
            return;
          }

          showPopup(
            "Success",
            "Password reset successful! Please sign in with your new password.",
            { onClose: () => window.location.href = "join-us.html" }
          );

          forgotPasswordForm.reset();
          submittedEmail = "";
          resetTokenSent = false;
          tokenVerified = false;

          if (requestField) requestField.style.display = "";
          if (identifierInput) identifierInput.disabled = false;

          if (resetTokenInput) {
            resetTokenInput.disabled = true;
            resetTokenInput.readOnly = false;
            resetTokenInput.style.opacity = "1";
          }

          if (newPasswordInput) newPasswordInput.disabled = true;
          if (confirmPasswordInput) confirmPasswordInput.disabled = true;

          passwordFields.forEach(field => field.style.display = "none");
          if (tokenNote) tokenNote.style.display = "none";

          submitButton.textContent = "Send Reset Token";

        } catch (error) {
          console.error(error);
          restoreButton(submitButton);
          showPopup(
            "Server Error",
            "Unable to connect to server"
          );
        }
      });
    }
  };

  /* ══════════════════════════════════════════════════
     EVENT REGISTRATION MODAL LOGIC
  ══════════════════════════════════════════════════ */
  const setupEventRegistration = () => {
    const modal = document.getElementById("event-register-modal");
    const form = document.getElementById("event-register-form");
    const closeBtn = document.getElementById("modal-close-btn");
    const cancelBtn = document.getElementById("modal-cancel-btn");
    const submitBtn = document.getElementById("reg-submit-btn");
    const teamSizeSelect = document.getElementById("reg-team-size");
    const teamSection = document.getElementById("team-members-section");
    const teamFieldsWrap = document.getElementById("team-members-fields");

    if (!modal || !form) return;

    /* ── Open modal ── */
    const openModal = (eventId, eventTitle, maxTeamSize = 1) => {
      // Check if user is logged in
      const token = localStorage.getItem("token");
      if (!token) {
        showPopup("Login Required", "Please log in to register for events.", {
          onClose: () => { window.location.href = "join-us.html"; }
        });
        return;
      }

      // Pre-fill hidden fields
      document.getElementById("reg-event-id").value = eventId;
      document.getElementById("reg-event-title").value = eventTitle;
      document.getElementById("modal-event-title").textContent = eventTitle;

      // Auto-fill from stored user profile
      try {
        const userStr = localStorage.getItem("user");
        if (userStr) {
          const user = JSON.parse(userStr);
          if (user.name) document.getElementById("reg-fullname").value = user.name;
          if (user.email) document.getElementById("reg-email").value = user.email;
        }
      } catch { }

      // Populate team size options based on maxTeamSize
      if (teamSizeSelect) {
        teamSizeSelect.innerHTML = "";
        for (let i = 1; i <= maxTeamSize; i++) {
          const opt = document.createElement("option");
          opt.value = i;
          opt.textContent = i === 1 ? "1 (Solo)" : i;
          teamSizeSelect.appendChild(opt);
        }
      }

      // Reset team fields
      teamSizeSelect.value = "1";
      teamSection.style.display = "none";
      teamFieldsWrap.innerHTML = "";

      modal.classList.add("open");
      document.body.style.overflow = "hidden";
    };

    /* ── Close modal ── */
    const closeModal = () => {
      modal.classList.remove("open");
      document.body.style.overflow = "";
      form.reset();
      teamSection.style.display = "none";
      teamFieldsWrap.innerHTML = "";
    };

    closeBtn?.addEventListener("click", closeModal);
    cancelBtn?.addEventListener("click", closeModal);
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal.classList.contains("open")) closeModal();
    });


    const renderTeamFields = (size) => {
      const count = size - 1;
      if (count <= 0) {
        teamSection.style.display = "none";
        teamFieldsWrap.innerHTML = "";
        return;
      }
      teamSection.style.display = "";
      teamFieldsWrap.innerHTML = Array.from({ length: count }, (_, i) => `
        <div class="team-member-row">
          <p class="team-member-label">Member ${i + 2}</p>
          <input type="text" name="tm-name-${i}" placeholder="Full Name" required />
          <input type="text" name="tm-usn-${i}"  placeholder="1JT24IS060" pattern="\\d[a-zA-Z]{2}\\d{2}[a-zA-Z]{2}\\d{3}" title="Please enter a valid USN in the format 1JT24IS052" required />
        </div>
      `).join("");
    };

    teamSizeSelect.addEventListener("change", () => {
      renderTeamFields(Number(teamSizeSelect.value));
    });


    document.addEventListener("click", async (e) => {
      const btn = e.target.closest("[data-reg-event-id]");
      if (!btn) return;

      const token = localStorage.getItem("token");
      const eventId = btn.dataset.regEventId;

      // Pre-check if user is already registered for this event
      if (token) {
        try {
          const res = await fetch(`${API_BASE_URL}/events/my-registrations`, {
            headers: { "Authorization": `Bearer ${token}` }
          });
          const data = await res.json();
          if (data.success && data.registrations) {
            const alreadyRegistered = data.registrations.some(r => r.eventId === eventId);
            if (alreadyRegistered) {
              showPopup("Already Registered", "You have already registered for this event.");
              return;
            }
          }
        } catch { /* proceed to open modal if check fails */ }
      }

      openModal(eventId, btn.dataset.regEventTitle, parseInt(btn.dataset.regEventTeamSize) || 1);
    });

    /* ── Form submission ── */
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const token = localStorage.getItem("token");
      if (!token) {
        showPopup("Login Required", "Please log in to register for events.");
        return;
      }

      setButtonBusy(submitBtn, "Submitting...");

      const teamSize = Number(teamSizeSelect.value);
      const teamMembers = [];
      if (teamSize > 1) {
        for (let i = 0; i < teamSize - 1; i++) {
          const name = form.querySelector(`[name="tm-name-${i}"]`)?.value.trim();
          const usn = form.querySelector(`[name="tm-usn-${i}"]`)?.value.trim();
          if (!name || !usn) {
            restoreButton(submitBtn);
            showPopup("Validation Error", `Please fill name and USN for team member ${i + 2}`);
            return;
          }
          teamMembers.push({ name, usn });
        }
      }

      const body = {
        eventId: document.getElementById("reg-event-id").value,
        eventTitle: document.getElementById("reg-event-title").value,
        fullName: document.getElementById("reg-fullname").value.trim(),
        email: document.getElementById("reg-email").value.trim(),
        phone: document.getElementById("reg-phone").value.trim(),
        collegeName: document.getElementById("reg-college").value.trim(),
        usn: document.getElementById("reg-usn").value.trim(),
        teamSize,
        teamMembers,
        notes: document.getElementById("reg-notes").value.trim()
      };

      try {
        const response = await fetch(`${API_BASE_URL}/events/register`, {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
          },
          body: JSON.stringify(body)
        });

        const data = await response.json();
        restoreButton(submitBtn);

        if (!response.ok) {
          showPopup("Registration Failed", data.message || "Something went wrong");
          return;
        }

        closeModal();
        showPopup("Success", "You have been successfully registered for this event!");
      } catch (error) {
        console.error(error);
        restoreButton(submitBtn);
        showPopup("Server Error", "Unable to connect to server. Please try again later.");
      }
    });
  };

  /* ══════════════════════════════════════
     Event Countdown Cards (Know-Us Neo-Brutalist Design)
     Adapted with vibrant rotating themes, stickers & brutalist countdown units
  ══════════════════════════════════════ */

  /**
   * Generates tailored dynamic neo-brutalist tech artwork & banners matching the event title/topic.
   */
  const getEventDynamicBanner = (event, theme) => {
    const text = `${event.title || ''} ${event.description || ''} ${theme?.category || ''}`.toLowerCase();

    // 1. Hackathon / Build Sprint / Dev Jam
    if (/hack|sprint|build|jam|matrix|devfest|ideathon/.test(text)) {
      return {
        bg: "linear-gradient(135deg, #0b1120 0%, #1e1b4b 45%, #312e81 80%, #0284c7 100%)",
        watermark: "HACK"
      };
    }

    // 2. Artificial Intelligence / Machine Learning / Deep Learning / Data Science
    if (/ai|neural|agent|model|machine learning|deep learning|vision|gpt|llm|intelligence|data/.test(text)) {
      return {
        bg: "linear-gradient(135deg, #180828 0%, #3b0764 45%, #581c87 80%, #7c3aed 100%)",
        watermark: "AI"
      };
    }

    // 3. Web Dev / Frontend / UI/UX / Fullstack
    if (/web|frontend|ui|ux|css|html|react|design|interface|craft|fullstack|javascript/.test(text)) {
      return {
        bg: "linear-gradient(135deg, #042f2e 0%, #064e3b 45%, #0d9488 80%, #0284c7 100%)",
        watermark: "WEB"
      };
    }

    // 4. Algorithms / Competitive Programming / DSA / Coding Quest
    if (/algo|algoquest|dsa|competitive|coding|logic|quest|leetcode|contest|problem/.test(text)) {
      return {
        bg: "linear-gradient(135deg, #0f172a 0%, #1e3a8a 45%, #2563eb 80%, #6366f1 100%)",
        watermark: "CODE"
      };
    }

    // 5. Cloud / DevOps / Backend / Systems / Docker / API
    if (/cloud|devops|docker|kubernetes|aws|backend|server|database|systems|pipeline/.test(text)) {
      return {
        bg: "linear-gradient(135deg, #0c4a6e 0%, #075985 45%, #0284c7 80%, #0d9488 100%)",
        watermark: "CLOUD"
      };
    }

    // 6. Cybersecurity / CTF / Security / Ethical Hacking
    if (/security|cyber|ctf|crypto|shield|auth|safe|defense|firewall/.test(text)) {
      return {
        bg: "linear-gradient(135deg, #3b0764 0%, #7f1d1d 45%, #991b1b 80%, #f43f5e 100%)",
        watermark: "SEC"
      };
    }

    // 7. Talks / Keynote / Summit / Conference / Induction
    if (/talk|keynote|summit|induction|conference|meet|inaugural|speaker/.test(text)) {
      return {
        bg: "linear-gradient(135deg, #3b1d03 0%, #78350f 45%, #92400e 80%, #d97706 100%)",
        watermark: "TALK"
      };
    }

    // 8. Dynamic fallback using event initials
    const words = (event.title || "Event").trim().split(/\s+/);
    const initials = words.slice(0, 2).map(w => w[0] || '').join('').toUpperCase() || 'ACM';
    return {
      bg: "linear-gradient(135deg, #0b1120 0%, #1e293b 45%, #334155 80%, #0f172a 100%)",
      watermark: initials
    };
  };

  /**
   * Creates one countdown card HTML string in the Know Us neo-brutalist style.
   * @param {Object} event - event object from API  { _id, title, date, description, status, teamSize, ... }
   * @param {number} index - index for stagger delay & theme selection
   * @returns {string} HTML string for a single countdown card
   */
  const createCountdownCardHTML = (event, index) => {
    const eventId = escapeHtml(event._id || "");
    const title = escapeHtml(event.title || "Upcoming Event");
    const rawDateStr = event.date || "";
    const dateStr = escapeHtml(formatDisplayDate(rawDateStr));
    const attendees = event.attendees || Math.floor(Math.random() * 40 + 15);
    const st = (event.status || "").toLowerCase();
    const isOpen = st.includes("open") && !st.includes("closed");
    const theme = EVENT_THEMES[index % EVENT_THEMES.length];
    const banner = getEventDynamicBanner(event, theme);

    const buttonText = isOpen ? "Reserve Your Spot" : "View Details";
    const buttonDataAttrs = isOpen
      ? `data-reg-event-id="${eventId}" data-reg-event-title="${title}" data-reg-event-team-size="${escapeHtml(String(event.teamSize || 1))}"`
      : "";

    return `
      <div class="countdown-card ${theme.themeClass}" data-countdown-card data-event-date="${escapeHtml(rawDateStr)}" style="animation-delay:${index * 0.08}s">
        <!-- Floating Event Sticker Badge -->
        <div class="event-sticker" title="${theme.category}">
          ${theme.stickerSvg}
        </div>

        <!-- Dynamic Context-Aware Event Graphic Banner -->
        <div class="countdown-card__graphic-wrap">
          <div class="countdown-card__graphic-bg" style="background: ${banner.bg};"></div>
          <div class="countdown-card__graphic-grid"></div>
          <div class="countdown-card__graphic-watermark">${banner.watermark}</div>

          <div class="countdown-card__urgency-badge" data-urgency-badge hidden>⏱ Starts Soon!</div>
          ${event.status ? `<div class="countdown-card__status-badge">${escapeHtml(event.status)}</div>` : ''}
        </div>

        <!-- Content -->
        <div class="countdown-card__content">
          <!-- Title & Meta -->
          <div>
            <div class="countdown-card__category">${theme.category}</div>
            <h3 class="countdown-card__title">${title}</h3>
            <div class="countdown-card__meta">
              <span class="countdown-card__meta-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                <span>${dateStr}</span>
              </span>
              ${event.teamSize ? `
              <span class="countdown-card__meta-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                <span>Team: ${escapeHtml(String(event.teamSize))} Max</span>
              </span>` : ''}
            </div>
          </div>

          <!-- Countdown Timer -->
          <div class="countdown-card__timer-wrap" data-countdown-timer>
            <div class="countdown-card__countdown-header">
              <svg viewBox="0 0 24 24" fill="none" stroke="#0B0F0D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              <span>Starts In:</span>
            </div>
            <div class="countdown-card__timer-grid">
              <div class="countdown-card__timer-unit">
                <div class="countdown-card__timer-value" data-days>00</div>
                <div class="countdown-card__timer-label">Days</div>
              </div>
              <div class="countdown-card__timer-unit">
                <div class="countdown-card__timer-value" data-hours>00</div>
                <div class="countdown-card__timer-label">Hours</div>
              </div>
              <div class="countdown-card__timer-unit">
                <div class="countdown-card__timer-value" data-minutes>00</div>
                <div class="countdown-card__timer-label">Min</div>
              </div>
              <div class="countdown-card__timer-unit countdown-card__timer-unit--seconds">
                <div class="countdown-card__timer-value" data-seconds>00</div>
                <div class="countdown-card__timer-label">Sec</div>
              </div>
            </div>
          </div>

          <!-- Event Started fallback (hidden by default) -->
          <div data-countdown-started style="display:none">
            <div class="countdown-card__started">
              <div class="countdown-card__started-title">🚀 Event Live!</div>
              <div class="countdown-card__started-desc">Check chapter stream or join now</div>
            </div>
          </div>

          <!-- Action Button -->
          <button type="button" class="countdown-card__btn btn-register-event" ${buttonDataAttrs}>
            <span>${buttonText}</span>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
          </button>
        </div>
      </div>`;
  };

  /**
   * Parses a display-date like "June 15, 2026" or "2026-06-15" into a Date.
   * Returns null if parsing fails.
   */
  const parseEventDate = (dateStr) => {
    if (!dateStr) return null;
    const d = new Date(dateStr);
    if (!isNaN(d.getTime())) return d;
    // Try appending a time for bare dates like "June 15, 2026"
    const d2 = new Date(dateStr + " 00:00:00");
    if (!isNaN(d2.getTime())) return d2;
    return null;
  };

  /**
   * Starts live countdown timers on all rendered countdown cards.
   */
  const startCountdownTimers = () => {
    const cards = document.querySelectorAll("[data-countdown-card]");
    if (!cards.length) return;

    const pad = (n) => String(n).padStart(2, "0");

    const tick = () => {
      const now = Date.now();

      cards.forEach((card) => {
        const dateStr = card.dataset.eventDate;
        let targetDate = parseEventDate(dateStr);

        // If no parseable date, default to ~2 days from page load
        if (!targetDate) {
          if (!card._fallbackDate) {
            card._fallbackDate = new Date(Date.now() + 2 * 86400000 + 5 * 3600000 + 30 * 60000);
          }
          targetDate = card._fallbackDate;
        }

        const diff = Math.max(0, Math.floor((targetDate.getTime() - now) / 1000));

        const timerEl = card.querySelector("[data-countdown-timer]");
        const startedEl = card.querySelector("[data-countdown-started]");
        const btn = card.querySelector(".countdown-card__btn");
        const badge = card.querySelector("[data-urgency-badge]");

        if (diff <= 0) {
          // Event started
          if (timerEl) timerEl.style.display = "none";
          if (startedEl) startedEl.style.display = "";
          if (btn) btn.textContent = "Join Event";
          if (badge) badge.hidden = true;
        } else {
          if (timerEl) timerEl.style.display = "";
          if (startedEl) startedEl.style.display = "none";

          const days = Math.floor(diff / 86400);
          const hours = Math.floor((diff % 86400) / 3600);
          const minutes = Math.floor((diff % 3600) / 60);
          const seconds = diff % 60;

          const daysEl = card.querySelector("[data-days]");
          const hoursEl = card.querySelector("[data-hours]");
          const minutesEl = card.querySelector("[data-minutes]");
          const secondsEl = card.querySelector("[data-seconds]");

          if (daysEl) daysEl.textContent = pad(days);
          if (hoursEl) hoursEl.textContent = pad(hours);
          if (minutesEl) minutesEl.textContent = pad(minutes);
          if (secondsEl) secondsEl.textContent = pad(seconds);

          // Urgency badge: show if less than 24 hours
          if (badge) {
            badge.hidden = diff >= 86400;
          }
        }
      });
    };

    // Tick immediately, then every second
    tick();
    setInterval(tick, 1000);
  };

  /**
   * Fetches upcoming events from the API and renders countdown cards.
   */
  const renderCountdownCards = async () => {
    const grid = document.getElementById("countdown-cards-grid");
    const section = document.getElementById("countdown-cards-section");
    if (!grid || !section) return;

    const events = await fetchEvents();

    if (events.upcoming.length) {
      // Render cards (max 4 to keep section compact)
      const cardsToShow = events.upcoming.slice(0, 4);
      grid.innerHTML = cardsToShow.map((event, i) => createCountdownCardHTML(event, i)).join("");

      // Start live countdown timers
      startCountdownTimers();
      section.style.display = "";
    } else {
      // Hide section if no upcoming events
      section.style.display = "none";
    }
  };

  renderCountdownCards();
  renderPublicEvents();
  renderPublicAnnouncements();
  setupAnnFilterTabs();
  setupAdminPanel();
  setupAdminAnnouncements();
  setupAuthForms();
  setupEventRegistration();

  /* ── Navbar injection ── */
  const mount = document.getElementById("global-navbar");
  if (!mount) return;
  const mainScript = document.querySelector('script[src*="main.js"]');
  const navbarUrl = mainScript ? new URL("navbar.html", mainScript.src).href : "navbar.html";

  fetch(navbarUrl)
    .then((res) => {
      if (!res.ok) throw new Error("Unable to load navbar");
      return res.text();
    })
    .then((html) => {
      mount.innerHTML = html;

      const currentPage = window.location.pathname.split("/").pop() || "index.html";
      const activePageAliases = {
        "forgot-password.html": "join-us.html",
        "verify.html": "register.html"
      };
      const activePage = activePageAliases[currentPage] || currentPage;
      mount.querySelectorAll("a[href]").forEach((anchor) => {
        const rawHref = anchor.getAttribute("href");
        if (rawHref && !rawHref.startsWith("#")) {
          anchor.href = new URL(rawHref, navbarUrl).href;
        }
      });
      mount.querySelectorAll("img[src]").forEach((img) => {
        const rawSrc = img.getAttribute("src");
        if (rawSrc && !rawSrc.startsWith("http") && !rawSrc.startsWith("data:") && !rawSrc.startsWith("//")) {
          img.src = new URL(rawSrc, navbarUrl).href;
        }
      });
      const links = mount.querySelectorAll(".nav-link");

      links.forEach((link) => {
        const isActive = link.dataset.page === activePage;
        if (!isActive) return;
        if (link.classList.contains("nav-cta")) {
          link.style.boxShadow = "0 0 0 2px rgba(165,243,252,0.5)";
        } else {
          link.classList.add("active");
        }
      });

      const button = document.getElementById("nav-menu-button");
      const menu = document.getElementById("nav-links");
      if (button && menu) {
        button.addEventListener("click", () => {
          const isOpen = menu.classList.contains("open");
          menu.classList.toggle("open", !isOpen);
          button.setAttribute("aria-expanded", String(!isOpen));
        });
      }
      // CHECK LOGIN STATUS & VALIDATE WITH BACKEND
      const token = localStorage.getItem("token");
      if (!token) {
        // not logged in
        return;
      }

      // Validate token by fetching profile from backend with automatic silent refresh
      const fetchProfile = async () => {
        try {
          let currentToken = localStorage.getItem("token");
          let res = await fetch(`${API_BASE_URL}/auth/profile`, {
            credentials: "include",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${currentToken}`
            }
          });

          // If access token expired, try refreshing via HttpOnly refresh token cookie
          if (res.status === 401) {
            const refreshRes = await fetch(`${API_BASE_URL}/auth/refresh-token`, {
              method: "POST",
              credentials: "include"
            });

            if (refreshRes.ok) {
              const refreshData = await refreshRes.json();
              if (refreshData.accessToken) {
                currentToken = refreshData.accessToken;
                localStorage.setItem("token", currentToken);
                if (refreshData.user) {
                  const refreshedUser = sanitizeUser(refreshData.user);
                  localStorage.setItem("user", JSON.stringify(refreshedUser));
                  if (refreshedUser && refreshedUser.avatar) {
                    localStorage.setItem(`user_avatar_${refreshedUser.email}`, refreshedUser.avatar);
                  }
                }
                // Retry profile fetch with new access token
                res = await fetch(`${API_BASE_URL}/auth/profile`, {
                  credentials: "include",
                  headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${currentToken}`
                  }
                });
              }
            }
          }

          if (!res.ok) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            return null;
          }

          const profile = await res.json();
          return profile;
        } catch (err) {
          console.error("Profile check error:", err);
          return null;
        }
      };

      fetchProfile()
        .then((profile) => {
          if (!profile) return;

          // backend returns { success: true, user }
          const profileData = sanitizeUser(profile.user || profile);
          if (!profileData) return;

          // Update local user storage with fresh sanitized profile
          try {
            localStorage.setItem('user', JSON.stringify(profileData));
            if (profileData.avatar) {
              localStorage.setItem(`user_avatar_${profileData.email}`, profileData.avatar);
            }
          } catch { }

          // Redirect authenticated users away from guest-only auth pages
          const currentFile = window.location.pathname.split("/").pop() || "index.html";
          const isGuestAuth = currentFile === "join-us.html" || 
                              currentFile === "register.html" || 
                              window.location.pathname.endsWith("/join-us") || 
                              window.location.pathname.endsWith("/register");
          if (isGuestAuth) {
            window.location.replace("index.html");
            return;
          }

          // Hide auth links (register / join-us) for authenticated user
          menu.querySelectorAll("a").forEach(link => {
            const href = link.getAttribute("href");
            if (href?.includes("register") || href?.includes("join-us")) link.style.display = "none";
          });

          if (!document.getElementById("profile-drawer-css")) {
            const link = document.createElement("link");
            link.id = "profile-drawer-css";
            link.rel = "stylesheet";
            link.href = "./CSS/profile-drawer.css?v=2.0.2";
            document.head.appendChild(link);
          }

          const rightControls = document.getElementById("nav-right-controls") || document.getElementById("nav-menu-button");
          if (rightControls) {
            let currentAvatarUrl = profileData.avatar || localStorage.getItem(`user_avatar_${profileData.email}`) || `https://api.dicebear.com/7.x/micah/svg?seed=${encodeURIComponent(profileData.email)}&backgroundColor=transparent`;

            const existingNavAvatarImg = document.querySelector("#profile-avatar-btn img");
            if (existingNavAvatarImg) {
              existingNavAvatarImg.src = currentAvatarUrl;
            }

            if (!document.getElementById("profile-avatar-container")) {
              rightControls.insertAdjacentHTML('beforeend', `
              <div id="profile-avatar-container" class="profile-avatar-container" style="display:flex;align-items:center;position:relative;">
                <button type="button" id="profile-avatar-btn" style="width:2.35rem;height:2.35rem;border-radius:50%;background:#facc15;border:2px solid #0B0F0D;box-shadow:2px 2px 0px #0B0F0D;cursor:pointer;display:grid;place-items:center;padding:0;overflow:hidden;transition:transform 0.2s ease;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='none'" title="View Profile">
                  <img src="${currentAvatarUrl}" alt="Avatar" style="width:100%;height:100%;object-fit:cover;" />
                </button>
              </div>
            `);

              // Hook up avatar button click event to display profile modal
              document.getElementById("profile-avatar-btn")?.addEventListener("click", () => {
              // Check if modal already exists in DOM, if so remove it
              const existingModal = document.getElementById("profile-info-modal");
              if (existingModal) existingModal.remove();

              // Inject modal markup
              const modalHTML = `
              <div id="profile-info-modal">
                <div id="profile-modal-body">
                  <button id="close-profile-modal-btn" class="profile-close-btn" title="Close">×</button>
                  
                  <!-- Header Dossier Card -->
                  <div class="profile-header-card">
                    <div class="profile-avatar-frame-wrap">
                      <div class="profile-avatar-frame" id="profile-avatar-frame" title="Click to choose DiceBear avatar">
                        <img id="profile-modal-avatar-img" src="${currentAvatarUrl}" alt="Avatar" class="profile-avatar-img" />
                      </div>
                      <button id="edit-profile-avatar-btn" class="profile-avatar-edit-btn" title="Choose DiceBear Avatar">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                      </button>
                    </div>
                    
                    <div id="profile-name-display-container" class="profile-name-row">
                      <h3 id="profile-name-display" class="profile-name-text">${profileData.fullName || profileData.name || "User"}</h3>
                      <button id="edit-profile-name-btn" class="profile-name-edit-btn" title="Edit Name">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                      </button>
                    </div>

                    <div id="profile-name-edit-container" class="profile-edit-box">
                      <input type="text" id="profile-name-input" class="profile-edit-input" value="${profileData.fullName || profileData.name || "User"}" />
                      <button id="save-profile-name-btn" class="profile-edit-save-btn">Save</button>
                      <button id="cancel-profile-name-btn" class="profile-edit-cancel-btn">✖</button>
                    </div>

                    <p class="profile-email-text">${profileData.email}</p>
                    <span class="profile-role-badge">
                      <span></span> ${profileData.role || 'Student Member'}
                    </span>
                  </div>

                  <!-- Body / Registered Events -->
                  <div class="profile-content-scroll" id="profile-registered-events-section">
                    <div class="profile-section-heading">
                      <span>Registered Events</span>
                      <span id="profile-event-badge" class="profile-event-counter">0</span>
                    </div>
                    
                    <div id="my-events-loader" style="text-align:center;padding:2rem 0;color:#94a3b8;">
                      <div style="width:1.5rem;height:1.5rem;border:2.5px solid #0B0F0D;border-top-color:#38bdf8;border-radius:50%;margin:0 auto 0.75rem;animation:spin 0.8s linear infinite;"></div>
                      Loading your events...
                    </div>
                    <div id="my-events-list" style="display:none;flex-direction:column;gap:0.75rem;"></div>
                  </div>

                  <!-- Footer Bar -->
                  <div class="profile-footer-bar">
                    <button id="theme-toggle-btn" class="profile-theme-btn" type="button" title="Toggle Light/Dark Theme">
                      <svg id="theme-toggle-sun" style="width:1rem;height:1rem;display:none;color:#d97706;" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="5"></circle>
                        <line x1="12" y1="1" x2="12" y2="3"></line>
                        <line x1="12" y1="21" x2="12" y2="23"></line>
                        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                        <line x1="1" y1="12" x2="3" y2="12"></line>
                        <line x1="21" y1="12" x2="23" y2="12"></line>
                        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                      </svg>
                      <svg id="theme-toggle-moon" style="width:1rem;height:1rem;display:none;color:#7c3aed;" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                      </svg>
                      <span id="theme-toggle-label">Theme</span>
                    </button>

                    <button id="profile-logout-btn" class="profile-logout-btn">
                      Logout
                    </button>
                  </div>
                </div>
              </div>

              <style>
                @keyframes spin { to { transform: rotate(360deg); } }
              </style>
            `;

              document.body.insertAdjacentHTML("beforeend", modalHTML);

              const modal = document.getElementById("profile-info-modal");
              const modalBody = document.getElementById("profile-modal-body");

              // Setup Theme Switcher Controls
              const toggleBtn = document.getElementById("theme-toggle-btn");
              const sunIcon = document.getElementById("theme-toggle-sun");
              const moonIcon = document.getElementById("theme-toggle-moon");
              const toggleLabel = document.getElementById("theme-toggle-label");

              const updateToggleUI = (theme) => {
                if (theme === "light") {
                  if (sunIcon) sunIcon.style.display = "block";
                  if (moonIcon) moonIcon.style.display = "none";
                  if (toggleLabel) toggleLabel.textContent = "Light Mode";
                } else {
                  if (sunIcon) sunIcon.style.display = "none";
                  if (moonIcon) moonIcon.style.display = "block";
                  if (toggleLabel) toggleLabel.textContent = "Dark Mode";
                }
              };

              const activeTheme = localStorage.getItem("theme") || "light";
              updateToggleUI(activeTheme);

              toggleBtn?.addEventListener("click", () => {
                const isLight = document.body.classList.contains("light-theme");
                const nextTheme = isLight ? "dark" : "light";

                if (nextTheme === "light") {
                  document.body.classList.add("light-theme");
                  document.documentElement.classList.add("light-theme");
                } else {
                  document.body.classList.remove("light-theme");
                  document.documentElement.classList.remove("light-theme");
                }

                localStorage.setItem("theme", nextTheme);
                updateToggleUI(nextTheme);
              });

              // Animate in
              setTimeout(() => {
                if (modal) modal.style.opacity = "1";
                if (modalBody) modalBody.style.transform = "translateX(0)";
              }, 10);

              // Close handlers
              const closeModal = () => {
                if (modal) modal.style.opacity = "0";
                if (modalBody) modalBody.style.transform = "translateX(100%)";
                setTimeout(() => {
                  modal?.remove();
                }, 400);
              };

              document.getElementById("close-profile-modal-btn")?.addEventListener("click", closeModal);
              modal?.addEventListener("click", (e) => {
                if (e.target === modal) closeModal();
              });

              // Logout handler
              document.getElementById("profile-logout-btn")?.addEventListener("click", async () => {
                try {
                  await fetch(`${API_BASE_URL}/auth/logout`, {
                    method: "POST",
                    credentials: "include"
                  });
                } catch (e) { }
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                window.location.reload();
              });

              // DiceBear Avatar Picker Modal Function
              const openDicebearPicker = () => {
                const existingPicker = document.getElementById("dicebear-picker-modal");
                if (existingPicker) existingPicker.remove();

                const dicebearStyles = [
                  { id: "micah", name: "Micah", icon: "", presets: ["Felix", "Luna", "Alex", "Milo", "Zoe", "Sam", "Leo", "Nova"] },
                  { id: "adventurer", name: "Adventurer", icon: "", presets: ["Knight", "Mage", "Rogue", "Scout", "Hero", "Valkyrie", "Ranger", "Warrior"] },
                  { id: "bottts", name: "Bottts", icon: "", presets: ["Cyber", "Sparky", "Gizmo", "Byte", "Pixel", "Unit-7", "Matrix", "Echo"] },
                  { id: "fun-emoji", name: "Fun Emoji", icon: "", presets: ["Joy", "Wink", "Grin", "Star", "Happy", "Cool", "Love", "Cheer"] },
                  { id: "pixel-art", name: "Pixel Art", icon: "", presets: ["Retro", "Arcade", "Gamer", "Quest", "Glitch", "Bit", "Chief", "Player1"] },
                  { id: "lorelei", name: "Lorelei", icon: "", presets: ["Aria", "Elena", "Sophia", "Chloe", "Maya", "Ivy", "Lily", "Amara"] }
                ];

                let selectedStyle = "micah";
                let selectedSeed = "Felix";

                try {
                  const urlObj = new URL(currentAvatarUrl);
                  const pathParts = urlObj.pathname.split("/");
                  if (pathParts.length >= 3 && pathParts[1] === "7.x") {
                    const matchStyle = dicebearStyles.find(s => s.id === pathParts[2]);
                    if (matchStyle) selectedStyle = matchStyle.id;
                  }
                  const seedParam = urlObj.searchParams.get("seed");
                  if (seedParam) selectedSeed = decodeURIComponent(seedParam);
                } catch { }

                const pickerMarkup = `
                <div id="dicebear-picker-modal" class="dicebear-picker-overlay">
                  <div class="dicebear-picker-modal">
                    <div class="dicebear-picker-header">
                      <h3 class="dicebear-picker-title">
                        <span>✦</span> Choose Avatar
                      </h3>
                      <button id="close-dicebear-picker-btn" class="dicebear-picker-close" title="Close">×</button>
                    </div>

                    <div class="dicebear-picker-body">
                      <!-- Live Preview Box -->
                      <div class="dicebear-preview-box">
                        <div class="dicebear-preview-circle" id="dicebear-live-preview-circle">
                          <img id="dicebear-live-preview-img" src="https://api.dicebear.com/7.x/${selectedStyle}/svg?seed=${encodeURIComponent(selectedSeed)}&backgroundColor=transparent" alt="Preview" />
                        </div>
                        <div class="dicebear-preview-info">
                          <div style="display:flex;align-items:center;gap:0.4rem;">
                            <span class="dicebear-style-badge" id="dicebear-preview-badge">${selectedStyle}</span>
                          </div>
                          <span style="font-size:0.78rem;font-weight:800;opacity:0.9;" id="dicebear-preview-seed-label">${escapeHtml(selectedSeed)}</span>
                          <button type="button" id="dicebear-randomize-btn" class="dicebear-random-btn">
                             Random Pick
                          </button>
                        </div>
                      </div>

                      <!-- Style Selector Chips (Clean Wrap, No Horizontal Scrollbar) -->
                      <div>
                        <div class="dicebear-section-label">
                          <span>Avatar Category</span>
                        </div>
                        <div class="dicebear-styles-wrap" id="dicebear-styles-list">
                          ${dicebearStyles.map(st => `
                            <button type="button" class="dicebear-style-chip ${st.id === selectedStyle ? 'is-active' : ''}" data-style="${st.id}">
                              ${st.icon} ${st.name}
                            </button>
                          `).join("")}
                        </div>
                      </div>

                      <!-- Preset Avatars Grid -->
                      <div>
                        <div class="dicebear-section-label">
                          <span>Choose Character</span>
                        </div>
                        <div class="dicebear-grid" id="dicebear-presets-grid">
                          <!-- Injected dynamically -->
                        </div>
                      </div>
                    </div>

                    <div class="dicebear-picker-footer">
                      <button type="button" id="cancel-dicebear-btn" class="dicebear-btn-cancel">Cancel</button>
                      <button type="button" id="save-dicebear-btn" class="dicebear-btn-save">Set Avatar</button>
                    </div>
                  </div>
                </div>
                `;

                document.body.insertAdjacentHTML("beforeend", pickerMarkup);

                const pickerModal = document.getElementById("dicebear-picker-modal");
                const liveImg = document.getElementById("dicebear-live-preview-img");
                const styleBadge = document.getElementById("dicebear-preview-badge");
                const seedLabel = document.getElementById("dicebear-preview-seed-label");
                const presetsGrid = document.getElementById("dicebear-presets-grid");

                // Animate in
                setTimeout(() => {
                  if (pickerModal) {
                    pickerModal.style.opacity = "1";
                    const m = pickerModal.querySelector(".dicebear-picker-modal");
                    if (m) m.style.transform = "scale(1) translateY(0)";
                  }
                }, 10);

                const updatePreview = () => {
                  const url = `https://api.dicebear.com/7.x/${selectedStyle}/svg?seed=${encodeURIComponent(selectedSeed)}&backgroundColor=transparent`;
                  if (liveImg) liveImg.src = url;
                  if (styleBadge) styleBadge.textContent = selectedStyle;
                  if (seedLabel) seedLabel.textContent = selectedSeed;
                };

                const renderPresets = () => {
                  const currentStyleObj = dicebearStyles.find(s => s.id === selectedStyle) || dicebearStyles[0];
                  if (!presetsGrid) return;
                  presetsGrid.innerHTML = currentStyleObj.presets.map(preset => {
                    const presetUrl = `https://api.dicebear.com/7.x/${selectedStyle}/svg?seed=${encodeURIComponent(preset)}&backgroundColor=transparent`;
                    const isSelected = selectedSeed.toLowerCase() === preset.toLowerCase();
                    return `
                      <div class="dicebear-avatar-card ${isSelected ? 'is-selected' : ''}" data-seed="${escapeHtml(preset)}">
                        <div class="dicebear-avatar-thumb">
                          <img src="${presetUrl}" alt="${escapeHtml(preset)}" loading="lazy" />
                        </div>
                        <span class="dicebear-avatar-name">${escapeHtml(preset)}</span>
                      </div>
                    `;
                  }).join("");

                  presetsGrid.querySelectorAll(".dicebear-avatar-card").forEach(card => {
                    card.addEventListener("click", () => {
                      selectedSeed = card.dataset.seed;
                      presetsGrid.querySelectorAll(".dicebear-avatar-card").forEach(c => c.classList.remove("is-selected"));
                      card.classList.add("is-selected");
                      updatePreview();
                    });
                  });
                };

                renderPresets();

                // Style chip click
                document.querySelectorAll(".dicebear-style-chip").forEach(chip => {
                  chip.addEventListener("click", () => {
                    document.querySelectorAll(".dicebear-style-chip").forEach(c => c.classList.remove("is-active"));
                    chip.classList.add("is-active");
                    selectedStyle = chip.dataset.style;
                    const styleObj = dicebearStyles.find(s => s.id === selectedStyle) || dicebearStyles[0];
                    selectedSeed = styleObj.presets[0];
                    renderPresets();
                    updatePreview();
                  });
                });

                // Random pick button
                document.getElementById("dicebear-randomize-btn")?.addEventListener("click", () => {
                  const currentStyleObj = dicebearStyles.find(s => s.id === selectedStyle) || dicebearStyles[0];
                  const randomPreset = currentStyleObj.presets[Math.floor(Math.random() * currentStyleObj.presets.length)];
                  selectedSeed = randomPreset;
                  presetsGrid.querySelectorAll(".dicebear-avatar-card").forEach(c => {
                    c.classList.toggle("is-selected", c.dataset.seed.toLowerCase() === selectedSeed.toLowerCase());
                  });
                  updatePreview();
                });

                // Close helper
                const closePicker = () => {
                  if (pickerModal) {
                    pickerModal.style.opacity = "0";
                    const m = pickerModal.querySelector(".dicebear-picker-modal");
                    if (m) m.style.transform = "scale(0.92) translateY(20px)";
                    setTimeout(() => pickerModal.remove(), 250);
                  }
                };

                document.getElementById("close-dicebear-picker-btn")?.addEventListener("click", closePicker);
                document.getElementById("cancel-dicebear-btn")?.addEventListener("click", closePicker);
                pickerModal.addEventListener("click", (e) => {
                  if (e.target === pickerModal) closePicker();
                });

                // Save button
                document.getElementById("save-dicebear-btn")?.addEventListener("click", async () => {
                  const saveBtn = document.getElementById("save-dicebear-btn");
                  const newAvatarUrl = `https://api.dicebear.com/7.x/${selectedStyle}/svg?seed=${encodeURIComponent(selectedSeed)}&backgroundColor=transparent`;

                  if (saveBtn) {
                    saveBtn.textContent = "Saving...";
                    saveBtn.disabled = true;
                  }

                  // Sync with backend (with automatic silent refresh if access token expired)
                  try {
                    let currentAuthToken = localStorage.getItem("token") || token;
                    let res = await fetch(`${API_BASE_URL}/auth/profile/avatar`, {
                      method: "PUT",
                      credentials: "include",
                      headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${currentAuthToken}`
                      },
                      body: JSON.stringify({ avatar: newAvatarUrl })
                    });

                    // If access token expired, try silent refresh
                    if (res.status === 401) {
                      const refreshRes = await fetch(`${API_BASE_URL}/auth/refresh-token`, {
                        method: "POST",
                        credentials: "include"
                      });
                      if (refreshRes.ok) {
                        const refreshData = await refreshRes.json();
                        if (refreshData.accessToken) {
                          currentAuthToken = refreshData.accessToken;
                          localStorage.setItem("token", currentAuthToken);
                          res = await fetch(`${API_BASE_URL}/auth/profile/avatar`, {
                            method: "PUT",
                            credentials: "include",
                            headers: {
                              "Content-Type": "application/json",
                              "Authorization": `Bearer ${currentAuthToken}`
                            },
                            body: JSON.stringify({ avatar: newAvatarUrl })
                          });
                        }
                      }
                    }

                    if (res && res.ok) {
                      const resData = await res.json().catch(() => ({}));
                      const savedAvatar = (resData.user && resData.user.avatar) ? resData.user.avatar : newAvatarUrl;

                      currentAvatarUrl = savedAvatar;
                      profileData.avatar = savedAvatar;

                      // Update UI elements immediately
                      const modalAvatarImg = document.getElementById("profile-modal-avatar-img");
                      if (modalAvatarImg) modalAvatarImg.src = savedAvatar;

                      const navAvatarImg = document.querySelector("#profile-avatar-btn img");
                      if (navAvatarImg) navAvatarImg.src = savedAvatar;

                      // Save locally
                      localStorage.setItem(`user_avatar_${profileData.email}`, savedAvatar);
                      try {
                        const cached = JSON.parse(localStorage.getItem("user") || "{}");
                        cached.avatar = savedAvatar;
                        localStorage.setItem("user", JSON.stringify(cached));
                      } catch { }

                      closePicker();
                    } else {
                      const resData = await res?.json().catch(() => ({}));
                      console.warn("Could not sync avatar with backend, status:", res?.status);
                      alert("Could not update avatar: " + (resData?.message || `Error ${res?.status || "Unknown"}`));
                      if (saveBtn) {
                        saveBtn.textContent = "Set Avatar";
                        saveBtn.disabled = false;
                      }
                    }
                  } catch (e) {
                    console.warn("Could not sync avatar with backend:", e);
                    alert("Could not connect to server to update avatar.");
                    if (saveBtn) {
                      saveBtn.textContent = "Set Avatar";
                      saveBtn.disabled = false;
                    }
                  }
                });
              };

              // Hook up avatar edit button and avatar frame click
              document.getElementById("edit-profile-avatar-btn")?.addEventListener("click", (e) => {
                e.stopPropagation();
                openDicebearPicker();
              });
              document.getElementById("profile-avatar-frame")?.addEventListener("click", () => {
                openDicebearPicker();
              });

              // Name edit handlers
              const nameDisplayContainer = document.getElementById("profile-name-display-container");
              const nameEditContainer = document.getElementById("profile-name-edit-container");
              const nameDisplay = document.getElementById("profile-name-display");
              const nameInput = document.getElementById("profile-name-input");
              const saveNameBtn = document.getElementById("save-profile-name-btn");

              document.getElementById("edit-profile-name-btn")?.addEventListener("click", () => {
                nameDisplayContainer.style.display = "none";
                nameEditContainer.style.display = "flex";
                nameInput.focus();
              });

              document.getElementById("cancel-profile-name-btn")?.addEventListener("click", () => {
                nameEditContainer.style.display = "none";
                nameDisplayContainer.style.display = "flex";
                nameInput.value = nameDisplay.textContent.trim();
              });

              saveNameBtn?.addEventListener("click", async () => {
                const newName = nameInput.value.trim();
                if (!newName) return;

                saveNameBtn.textContent = "...";
                saveNameBtn.disabled = true;

                try {
                  const currentAuthToken = localStorage.getItem("token") || token;
                  const res = await fetch(`${API_BASE_URL}/auth/profile/name`, {
                    method: "PUT",
                    credentials: "include",
                    headers: {
                      "Content-Type": "application/json",
                      "Authorization": `Bearer ${currentAuthToken}`
                    },
                    body: JSON.stringify({ name: newName })
                  });
                  const data = await res.json();
                  if (data.success) {
                    nameDisplay.textContent = newName;
                    const cachedUser = sanitizeUser(JSON.parse(localStorage.getItem('user') || "{}")) || {};
                    cachedUser.name = newName;
                    localStorage.setItem('user', JSON.stringify(cachedUser));
                  } else {
                    alert("Failed to update name: " + (data.message || "Unknown error"));
                  }
                } catch (e) {
                  alert("Error updating name.");
                }

                saveNameBtn.textContent = "Save";
                saveNameBtn.disabled = false;
                nameEditContainer.style.display = "none";
                nameDisplayContainer.style.display = "flex";
              });

              // Fetch registrations from new endpoint!
              fetch(`${API_BASE_URL}/events/my-registrations`, {
                headers: {
                  "Authorization": `Bearer ${token}`
                }
              })
                .then(res => res.json())
                .then(data => {
                  const loader = document.getElementById("my-events-loader");
                  const container = document.getElementById("my-events-list");
                  const countBadge = document.getElementById("profile-event-badge");
                  if (loader) loader.style.display = "none";
                  if (container) container.style.display = "flex";

                  if (!data.success || !data.registrations || data.registrations.length === 0) {
                    if (countBadge) countBadge.textContent = "0";
                    if (container) {
                      container.innerHTML = `
                    <div class="profile-empty-state">
                      <p>You haven't registered for any events yet.</p>
                      <a href="events.html" class="profile-browse-btn">
                        <span></span> Browse Events
                      </a>
                    </div>
                  `;
                    }
                    return;
                  }

                  if (countBadge) countBadge.textContent = data.registrations.length;

                  if (container) {
                    container.innerHTML = data.registrations.map(reg => `
                  <div class="profile-event-card">
                    <div class="profile-event-top">
                      <h5 class="profile-event-title">${reg.eventTitle}</h5>
                      <span class="profile-event-status-pill">Registered</span>
                    </div>
                    <div class="profile-event-meta">
                      <div><strong>USN:</strong> ${reg.usn}</div>
                      <div><strong>College:</strong> ${reg.collegeName}</div>
                      ${reg.teamSize > 1 ? `
                        <div style="margin-top:0.35rem;padding-top:0.35rem;border-top:1px dashed rgba(11,15,13,0.2);">
                          <strong>Team Size:</strong> ${reg.teamSize}
                          <div style="font-size:0.72rem;margin-top:0.25rem;max-height:60px;overflow-y:auto;">
                            ${reg.teamMembers.map((m, idx) => `<div>${idx + 1}. ${m.name} (${m.usn})</div>`).join('')}
                          </div>
                        </div>
                      ` : ''}
                    </div>
                  </div>
                `).join("");
                  }
                })
                .catch(err => {
                  console.error(err);
                  const loader = document.getElementById("my-events-loader");
                  if (loader) {
                    loader.innerHTML = `<span style="color:var(--rose-300);font-family:var(--font-body,'Inter',sans-serif);">⚠️ Error loading your events. Please try again.</span>`;
                  }
                });
            });
          }
        }

          const isAdmin = !!(profileData && (profileData.isAdmin || (typeof profileData.role === 'string' && profileData.role.toLowerCase() === 'admin') || (Array.isArray(profileData.roles) && profileData.roles.map(r => String(r).toLowerCase()).includes('admin'))));

          if (isAdmin) {
            // Resolve relative paths using navbarUrl so they don't break inside the nested admin/ folder!
            const adminHtmlUrl = new URL("admin/admin.html", navbarUrl).href;
            const adminUsersUrl = new URL("admin/users.html", navbarUrl).href;
            const adminAnalyticsUrl = new URL("admin/analytics.html", navbarUrl).href;

            // Insert admin dropdown
            menu.insertAdjacentHTML('beforeend', `
            <div class="admin-dropdown" style="position:relative;">
              <button type="button" id="admin-menu-toggle" class="nav-link" style="cursor:pointer;background:transparent;border:none;color:inherit;">Admin ▾</button>
              <div id="admin-menu" style="position:absolute;right:0;top:calc(100% + 8px);display:none;min-width:180px;border-radius:0.75rem;padding:0.5rem;background:rgba(2,6,23,0.95);border:1px solid rgba(255,255,255,0.06);box-shadow:0 10px 30px rgba(2,6,23,0.5);">
                <a class="nav-link" href="${adminHtmlUrl}" style="display:block;padding:0.5rem 0.75rem;">Manage Events</a>
                <a class="nav-link" href="${adminUsersUrl}" style="display:block;padding:0.5rem 0.75rem;">User Management</a>
                <a class="nav-link" href="${adminAnalyticsUrl}" style="display:block;padding:0.5rem 0.75rem;">Analytics</a>
              </div>
            </div>
          `);

            const toggleBtn = document.getElementById('admin-menu-toggle');
            const adminMenu = document.getElementById('admin-menu');
            toggleBtn?.addEventListener('click', (e) => {
              const open = adminMenu.style.display === 'block';
              adminMenu.style.display = open ? 'none' : 'block';
            });
            // close when clicking outside
            document.addEventListener('click', (e) => {
              if (!e.target.closest('.admin-dropdown')) {
                const m = document.getElementById('admin-menu');
                if (m) m.style.display = 'none';
              }
            });
          }

          // Admin controls may be added after profile validation.
          // The logout button is already rendered when a token exists.
        })
        .catch(() => {
          // network error — keep showing basic UI but do not expose admin
        });
    })
    .catch(() => {
      mount.innerHTML =
        '<div style="position:fixed;inset:0 0 auto;z-index:50;background:#020617;padding:1rem;text-align:center;font-size:0.875rem;color:#a5f3fc;">ACM JIT</div>';
    });
  /* ── Scroll Reveal Animation ── */
  const revealElements = document.querySelectorAll('.reveal');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  revealElements.forEach(el => revealObserver.observe(el));

});

// Stats Cards Initialization
(function initStatsCards() {
  const grid = document.getElementById('stats-cards-grid');
  if (!grid) return;

  const stats = [
    {
      number: '4+',
      label: 'Technical Domains',
      category: 'CORE DISCIPLINES',
      theme: 'theme-cyan'
    },
    {
      number: '5+',
      label: 'Events Conducted',
      category: 'COMMUNITY IMPACT',
      theme: 'theme-green'
    },
    {
      number: '28+',
      label: 'Active Members',
      category: 'STUDENT NETWORK',
      theme: 'theme-purple'
    },
    {
      number: '∞',
      label: 'Ideas Welcome',
      category: 'OPEN HORIZON',
      theme: 'theme-yellow'
    }
  ];

  grid.innerHTML = stats.map((stat, i) => `
    <div class="glass-card-wrapper">
      <div class="glass-card ${stat.theme}" style="top: calc(8vh + ${i * 24}px);">
        <!-- Giant Watermark Index -->
        <div class="glass-card-watermark">0${i + 1}</div>

        <!-- Top Bar -->
        <div class="glass-card-topbar">
          <span class="stat-pill-milestone">MILESTONE // 0${i + 1}</span>
          <span class="stat-pill-category">${stat.category}</span>
        </div>

        <!-- Center Content -->
        <div class="glass-card-center">
          <div class="stat-number-display">${stat.number}</div>
          <h3 class="stat-label-title">${stat.label}</h3>
        </div>
      </div>
    </div>
  `).join('');

  if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
    const cards = gsap.utils.toArray(grid.querySelectorAll(".glass-card"));
    const totalCards = cards.length;

    cards.forEach((card, index) => {
      const targetScale = 1 - (totalCards - index) * 0.04;

      gsap.set(card, {
        scale: 1,
        transformOrigin: "center top",
        force3D: true
      });

      const wrapper = card.parentElement;

      ScrollTrigger.create({
        trigger: wrapper,
        start: "top 35%",
        end: "bottom 65%",
        scrub: 1.0,
        onUpdate: (self) => {
          const progress = self.progress;
          const scale = gsap.utils.interpolate(1, targetScale, progress);

          gsap.set(card, {
            scale: Math.max(scale, targetScale),
            transformOrigin: "center top",
            z: 0,
            force3D: true
          });
        }
      });
    });
  }
})();

// Marquee Carousel Click & Touch Controls (Auto-resume after 3s)
(function initMarqueeControls() {
  const marqueeWrap = document.getElementById('marquee-wrap');
  if (!marqueeWrap) return;
  const marqueeTrack = document.getElementById('marquee-track');
  if (!marqueeTrack) return;

  let resumeTimer = null;

  const pauseAndAutoResume = () => {
    marqueeTrack.classList.add('is-paused');
    marqueeWrap.classList.add('is-paused');
    clearTimeout(resumeTimer);
    resumeTimer = setTimeout(() => {
      marqueeTrack.classList.remove('is-paused');
      marqueeWrap.classList.remove('is-paused');
    }, 3000);
  };

  marqueeWrap.addEventListener('click', pauseAndAutoResume);
  marqueeWrap.addEventListener('touchstart', pauseAndAutoResume, { passive: true });
})();


